# 潜藏追忆，如影随形

**dsh-auto-memory** — *She remembers, unbidden.*

> **中文** 该想起的，自己浮现。跨窗口 · 跨会话 · 跨工具，记忆不断线
>
> **EN** Now, across windows, too. Context that survives windows, sessions, and tools

<p align="center">
  <a href="https://htmlpreview.github.io/?https://github.com/Aik358/dsh-auto-memory/blob/preview/docs/landing/index.html"><strong>🌐 宣传主页（功能全景 · 数据流 · 论文 · 截图）</strong></a>
</p>

<p align="center">
  <a href="docs/screenshots/promo/promo-0-banner-v4.png"><img width="820" alt="dsh-auto-memory 主视觉：无问自忆，且件件可查" src="docs/screenshots/promo/promo-0-banner-v4.png"></a>
</p>

<p align="center">
  <a href="docs/screenshots/promo/promo-0-banner-v4.png"><img width="130" alt="主视觉" src="docs/screenshots/promo/promo-0-banner-v4.png"></a>
  <a href="docs/screenshots/promo/promo-1b-auto-recall.png"><img width="130" alt="自动唤起" src="docs/screenshots/promo/promo-1b-auto-recall.png"></a>
  <a href="docs/screenshots/promo/promo-2-tour.png"><img width="130" alt="欢迎向导" src="docs/screenshots/promo/promo-2-tour.png"></a>
  <a href="docs/screenshots/promo/promo-3-recall.png"><img width="130" alt="唤起与固化" src="docs/screenshots/promo/promo-3-recall.png"></a>
  <a href="docs/screenshots/promo/promo-4-unattended.png"><img width="130" alt="无人值守" src="docs/screenshots/promo/promo-4-unattended.png"></a>
  <a href="docs/screenshots/promo/promo-5-external.png"><img width="130" alt="外部记忆继承" src="docs/screenshots/promo/promo-5-external.png"></a>
  <a href="docs/screenshots/promo/promo-6-greeting.png"><img width="130" alt="定时问候" src="docs/screenshots/promo/promo-6-greeting.png"></a>
</p>
<p align="center"><sub>宣传图七幕 · 点击任意一张查看大图</sub></p>

<details>
<summary><b>宣传图分幕浏览</b>（点击展开，逐幕翻看）</summary>

#### 第一幕 · 主视觉 —— 不用吩咐，她自己记得

<p align="center"><img width="720" alt="主视觉" src="docs/screenshots/promo/promo-1-hero.png"></p>

#### 第二幕 · 自动唤起 —— 语义模型自动匹配，不等你问就已注入

<p align="center"><img width="720" alt="自动唤起" src="docs/screenshots/promo/promo-1b-auto-recall.png"></p>

#### 第三幕 · 欢迎向导 —— 每个功能，当场看懂、当场开关

<p align="center"><img width="720" alt="欢迎向导" src="docs/screenshots/promo/promo-2-tour.png"></p>

#### 第四幕 · 唤起与固化 —— 对话凝成技能，每一步有迹可循

<p align="center"><img width="720" alt="唤起与固化" src="docs/screenshots/promo/promo-3-recall.png"></p>

#### 第五幕 · 无人值守模式 —— 整夜安静跑，零寒暄，零打扰

<p align="center"><img width="720" alt="无人值守" src="docs/screenshots/promo/promo-4-unattended.png"></p>

#### 第六幕 · 外部记忆继承 —— 你的其他 AI，也在喂她记忆

<p align="center"><img width="720" alt="外部记忆继承" src="docs/screenshots/promo/promo-5-external.png"></p>

#### 第七幕 · 定时暖心问候 —— 让每一天都被记得

<p align="center"><img width="720" alt="定时问候" src="docs/screenshots/promo/promo-6-greeting.png"></p>

</details>

<p align="center">
  <a href="./README.zh-CN.md"><img alt="中文" src="https://img.shields.io/badge/%E4%B8%AD%E6%96%87-%E5%BD%93%E5%89%8D-blue?style=for-the-badge"></a>
  <a href="./README.md"><img alt="English" src="https://img.shields.io/badge/English-switch-lightgrey?style=for-the-badge"></a>
</p>

<p align="center">
  <a href="https://www.npmjs.com/package/@a9i5k4/dsh-auto-memory"><img alt="npm" src="https://img.shields.io/npm/v/@a9i5k4/dsh-auto-memory"></a>
  <a href="LICENSE"><img alt="License" src="https://img.shields.io/badge/License-BSD--3--Clause-yellow.svg"></a>
  <a href="https://www.npmjs.com/package/@a9i5k4/dsh-auto-memory"><img alt="npm downloads" src="https://img.shields.io/npm/dt/@a9i5k4/dsh-auto-memory"></a>
  <img alt="Platform" src="https://img.shields.io/badge/Platform-Windows%20%7C%20macOS%20%7C%20Linux-lightgrey">
</p>

<p align="center">
  <code>pnpm add @a9i5k4/dsh-auto-memory@latest</code>
</p>

<p align="center">
  <a href="docs/USER-GUIDE.zh-CN.md"><strong>📖 用户手册</strong></a> ·
  <a href="docs/USER-GUIDE.en.md"><strong>📖 User guide</strong></a> ·
  <a href="docs/SKIN-GUIDE.md"><strong>🎨 皮肤白皮书</strong></a> ·
  <a href="docs/TEAMWORK-GUIDE.md"><strong>👥 团队协作白皮书</strong></a> ·
  <a href="CHANGELOG.md">更新日志</a> ·
  <a href="https://htmlpreview.github.io/?https://github.com/Aik358/dsh-auto-memory/blob/main/docs/CONTRIBUTORS.html">贡献者与赞助</a> ·
  <a href="https://qm.qq.com/q/v7Asxn6vPa">QQ 交流群</a>
</p>

<h3 align="center">
  <a href="docs/SKIN-GUIDE.md">新款 <code>New UI</code></a> &nbsp;·&nbsp; 由
  <a href="https://github.com/Minervaowl7"><strong>@Minervaowl7</strong></a> 完整开发
</h3>

<p align="center">
  <a href="docs/skin-figures/skin-theme-compare.gif"><img width="720" alt="暗色与亮色主题滑动对比" src="docs/skin-figures/skin-theme-compare.gif"></a>
</p>
<p align="center"><sub>
暗色 ⇄ 亮色滑动对比 · 自动循环预览（GitHub README 不支持真实拖动；面板右上角可实时切换 <strong>暗色 / 亮色 / 跟随系统</strong>）。
</sub></p>

<p align="center">
  <img width="172" alt="记忆库" src="docs/skin-figures/skin-library-zh.png">
  &nbsp;<img width="172" alt="设置" src="docs/skin-figures/skin-settings-zh.png">
  &nbsp;<img width="172" alt="专注查看" src="docs/skin-figures/skin-tour-zh.png">
  &nbsp;<img width="172" alt="紧凑布局" src="docs/skin-figures/skin-compact-zh.png">
</p>

<p align="center"><sub>
一套参考图风格的记忆工作台：九页主导航、列表与详情分栏、四组设置分区、
专注查看、深色适配与窄屏布局。在记忆面板右上角即可切换 —— 经典皮肤一字未改，随时切回。
全部 24 张真机截图见
<a href="docs/SKIN-GUIDE.md"><strong>皮肤白皮书</strong></a>。
</sub></p>

> [!NOTE]
> **🧭 为官方长期记忆做好准备**
> 针对官方长期记忆系统的适配与预研正在进行中——正式上线后，本插件将**第一时间**提供与之配套的**语义唤回**与**跨窗口接续**。本插件一切皆开关，稳定性与灵活性充足：届时将自动适配、灵活辅助官方长期记忆体系，你的记忆无缝延续，无需任何迁移。

---

## 烧掉的书，留不住读后感

每一个用 AI 干正事的人，都经历过同一时刻：聊到一半，窗口满了，她"忘了"。不是不聪明，是她的思考被压缩成了一段摘要——像把一整本书烧掉，只留一句读后感。为什么这个方案修错了、那条路走不通，全在火里。

dsh-auto-memory 从第一天就不信这件事只能如此。她把记忆放在窗口外面：该想起的自动想起，不必吩咐；想起的每一条都有出处，可查、可改、可删。

现在，我们把这条路线推到最后一块拼图——上下文将满时，她不再压缩自己，而是**合上一本写满批注的笔记，翻开新的一页**。笔记还在手边，随时翻回去。

**压缩即失真，关窗即清零，换工具即归零——这三件事，从这里开始不成立。**

---

## 30 秒亮点

| | |
|---|---|
| **主动联想，零指令** | 记忆不靠模型调用——Host 观察情境自动唤回，经固定边界注入下一环节，前缀缓存友好 |
| **三层记忆引擎** | 用户级规则 → 项目笔记 → 每日日志，注入+按需检索 |
| **记忆自动沉淀** | 每轮对话结束由子代理静默判断去留，主题分组写入日志——你永远不需要记得"记一下" |
| **唤起有据可查** | 每次激活决策带完整证据链，唤起回顾页可复核打分；技能由跨会话证据渐进固化 |
| **主动式提醒** | AI 从对话中识别截止日期/约定，自动入日历并在后续会话中提醒 |
| **一切皆开关** | 欢迎向导+设置页双重入口，每个功能独立开关（含无人值守模式） |
| **外部记忆继承** | WorkBuddy / CodeBuddy / Claude Code / Codex 的历史记忆可扫描、导入、按源管理 |
| **生产级卫生** | 写入门禁（乱码/复读/JSON 注入拦截）+ 脏 token 扫描 + 凭证永不进提示词 |
| **Astra 式上下文管理** | 上下文将满不再压成一段摘要——四段式交接笔记跨窗口续命，全量历史归档可搜，Agent 按需检索（默认开启，阈值 0.75） |
| **多工作区不串线** | 同时开多个工作区 / 多个会话，各自的唤起判据与索引缓存互不覆盖——你点哪个工作区，都不影响正在跑的那个 |
| **模型无关** | 不锁厂商、不锁档位：DSH 上任何模型即装即得，词法 0GB 保底、内置语义 ~130MB、进阶 563MB |
| **记忆可携带** | 全部存在你自己的盘上；跨 AI 工具扫描导入，每条有证据链、可审计、可删除——记忆属于你，不属于任何厂商 |

---

## 四件花了心血的事

这个插件有四个功能，是我们一件一件亲手养大的；日历、检索、关系图、无人值守、记忆卫生……其余的一切特色，都围绕这四件生长。

### 第一件 · 会记事，也会问候

她最早学会的是两件小事：每次对话结束，把值得留的事写进记忆，不用你吩咐；在你暂离归来、清晨开工、深夜收尾的时刻，用合时宜的口吻说一声"欢迎回来"。听起来简单，但这两个动作定了她的性格——记忆不是数据库，问候不是提示音，是一个记得你的同事回来时的那句话。后来的一切能力，都长在这份性格上。我们从头到尾用"她"称呼这个插件，不是营销的包装——从第一个功能起，她就在做人才会做的事。

### 第二件 · 不只是想起来了去查，是做事时自然想起

人用记忆有两种方式：一种是刻意回想，翻找之前做过什么；更多的时候，是记忆在做事的当下自己涌上来。上一大版本，我们给了她后一种。给记忆库装上 Transformers 语义模型，让她在对话进行时判断两件事：此刻值不值得唤起，以及唤起哪一条——判断的材料就是你正在进行的思考与对话：你在想什么、说了什么、她答了什么。于是相关的记忆在模型开口之前，已经顺着上下文走到它该在的位置，经固定边界注入下一个环节。不依赖模型"记得去查"——忘了查，记忆就等于不存在；**她替你记得去想。**

### 第三件 · 像骑自行车，不用想怎么骑

人学会骑自行车之后，就不再回忆教学步骤——肌肉记忆接管一切，知识自然迁移到下一段路。她也在长这样的记性：多次观察到你的纠正、或反复做着同样相似的事，流程就固化成技能；下次再遇到相似的事，不用谁提醒，清单自动附上。刻意学的，变成顺手的——这是她的 procedural memory，也是「记忆中枢」页签里你能审批、能置顶、能看着她成长的那部分。

### 第四件 · 交接，而不是压缩

窗口将满时，她不再把整本书烧成一句读后感，而是写下四段式交接笔记——状态、目标、走过的弯路、下一步——合上这一页，翻开下一页；完整历史归档可搜，细节随时翻回去。这是四件心血里最新的一件，也是她完整记性的最后一块拼图——全文见[「她怎么交接」](#她怎么交接)。

---

## 为什么是插件

2026 年 9 月，GPT-6 Astra 把「上下文管理」作为旗舰实验特性发布：笔记跨窗口保留，历史归档可搜索，上下文快满时倾向交接而不是压缩。

看到这条公告，我们挺高兴——像独自走夜路的人，看见远处也亮起了灯。把记忆放到窗口外面：结构化的笔记、可搜索的归档、交接代替压缩——这条路上，原来不止我们一个行人。旗舰愿意为它按下 experimental 的按钮，说明这件事值得被更多人认真对待。

所以我们把它做成开放插件：没有 experimental 的门槛，也不绑定任何档位——装进 DSH，你机器上的任何模型，今天就有一份。

| | GPT-6 Astra / Codex 实验特性 | dsh-auto-memory |
|---|---|---|
| 可用性 | 单厂商旗舰、experimental | 开源插件，DSH 任何模型即装即得 |
| 笔记 | 跨窗口 keep notes | 四段式交接 ledger，用户可直接读改 |
| 归档 | 早期窗口可搜索 | 本地全量归档 + 词法/语义双臂检索 |
| 检索 | history/_context 工具 | memory_search / memory_note 门控代理工具 |
| 触发 | token budget + handoff | 水位感知 + 压缩前拦截 |
| 所有权 | 厂商侧 | 全在用户盘上，治理式写回可审计 |
| 分级 | 绑定订阅档位 | 0GB 词法 → 130MB 内置语义 → 563MB Python 进阶 |

**同一条路线，两种抵达：它随旗舰发布，我们随插件走进你的机器。**

*交接默认开启——阈值 0.75，恰好压在宿主 0.80 自动压缩线之下（见[「她怎么交接」](#她怎么交接)）。*

---

## 一个星期

周一，你交给她一个调研，中途关机。

周三，你换了台电脑，顺手把默认模型也换了。她接上的不是"抱歉，我不记得了"，而是上周的进度、三条已经试过的死路，和下一步。因为交接笔记在，原始记录可搜，记忆跟着你走。

周五，你随口问："你为什么记得这个？"她给你看：哪条消息、哪次工具输出、哪一次深夜反思写下的。你可以让她把这条记得更牢，也可以让她忘了那个。

**她记得，不必吩咐。你若要她忘，也只是一句话。**

> 交接相关情节默认开启，无需手动开启。

---

## 她怎么记

记忆分四层，各管一摊：

| 层 | 位置 | 内容 |
|---|---|---|
| 用户级记忆 | `~/.dsh/memory/MEMORY.md` | 跨项目规则与偏好 |
| 项目笔记 | `~/.dsh/memory/workspaces/{workspace}/MEMORY.md` | 项目约定与决策 |
| 每日日志 | `~/.dsh/memory/workspaces/{workspace}/YYYY-MM-DD.md` | 追加式工作日志 |
| 每日反思 | `…/reflections/YYYY-MM-DD.md` | 结构化复盘（成果/教训/下一步） |

静态纪律进 system prompt——字节级稳定，前缀缓存持续命中，从不反复重编码历史；动态记忆走运行时快照，只带最近一天的日志与反思摘要，其余按需经 `memory_read` / `memory_recall` 取回。**凭证/密钥段永远被过滤在提示词之外。**

**记，不需要你动手。** 每轮对话结束，一个小型子代理静默做一次"要不要记"的判断：值得记的主题分组写进日志（`## 主题（HH:MM）`+要点），长期决策晋升项目笔记，跨项目规则晋升用户级记忆，闲聊跳过。失败不慌——进队列，每 5 分钟重试，一个 15 秒心跳文件证明循环活着。每日写入有预算，超限时 AI 先合并去重再落笔——她记得节制，也记得不丢。

阶段性再回头一次：`memory_consolidate` 让她通读近期日志，发散提炼值得长期固化的要点升格进项目笔记——自动沉淀管"每轮结束记流水"，这一步管"过一阵子，什么值得留下来"。

---

## 她怎么想起

**不靠模型"记得去查"。** 市面上的记忆方案，要么要模型主动调一次检索工具，要么要你手动粘贴上下文——忘了调，记忆就等于不存在。这里是 Host 侧的联想中间件：对话进行时，她持续观察情境与运行事件，相关记忆在模型开口之前就被检索、决策、注入下一个环节。已发出去的请求不可改写，所以注入走固定边界——**前缀缓存永不失效，token 不为回忆买单两次。**她的判断材料就是对话本身：你在想什么、说了什么、她答了什么；值不值得唤起、唤起哪一条，由语义模型在对白进行中实时判断——不是想起来了才去查，是做事的时候自然想起。

权限也分了家：想起什么归语义决策管，该不该、什么时候归身份与时序治理管——每一次投递都有证据链。她递来的每一页还都过了安检：注入内容在全部出口中和模板变量——日志里一个普通的 `{{baseUrl}}`，再也不会卡住一整轮对话。

想主动问，随时开口：`memory_recall` 先返回分层摘要列表（每条记忆一个约 90 字的摘要，带 id、得分、匹配原因），词法 + 语义 + 时间三臂融合排序——问「上周的发布情况」，那一周的记忆就浮到前面；展开任意 id 即可取原文。会话式回答、逐条标注来源。`memory_recall` 天然跨工作区——别的项目的日志、笔记、结论，同样一句可达。

面板「工作区」页签把这一切画成一张关系图：中心是工作区，分支是记忆主题，虚线是跨区共享；可拖拽、可缩放、点卡片看详情。**你的记忆第一次有了形状。**

### 检索不是"把记忆全塞进去"——三层下探（OpenViking 式）

这里参考了 **OpenViking** 的分层思路，但按本仓语料的实测尺寸重新标定。核心是**逐层下探、不同时给**：

| 层 | 内容 | 预算 | 何时出现 |
|---|---|---|---|
| **Tier-0 · 目录**（指引层） | 每条 1 行 = 标题 · 结论 · 层 · 状态 · 日期 | ≤ `B0` = **800 token**（常驻，约 30 条） | **常态**：默认只注入这一层 |
| **Tier-1 · 摘要**（候选层） | 每条 ≤ `L1` = **140 字符**，取 `K` = **8** 条 | 8 × 140 = 1120 字符 | 目录命中不足才下探 |
| **Tier-2 · 原文块**（证据层） | `chunkId = hash(记忆ID, 内容摘要, 序号)` | ≤ `B2` = **2400 字符** / 次 | 需要证据才取 |

流程：`Tier-0 先出 → 缩窄 → 命中不足才下探 Tier-1 → 需要证据才取 Tier-2`。单轮注入总长仍受 `injectBudgetChars`（默认 8000 字符）约束。

**为什么这么设计（实测，不是拍脑袋）**：
- **原生语料比想象的小**：原文本身 p90 只有 **1196 字符**、max **1692**。所以 OpenViking 那种 `L0 → L1(2k) → L2` 的中间档可以省掉——从 140 字符的摘要直接跳到 ≤2400 的原文块，跨度可接受。
- **纯优先级会让分层退化**：真实语料实测，`project` 层 77 个块能把 800 token **全占**，`whiteboard` / `user` / `log` 一条都进不来——"分层"就成了单层。因此**每层有配额**（如 `project ≤ 60% · B0`），这是硬规则不是建议。
- **对账口径**：抽真实 `expand` 与语料长度比对，`mem_d55f8e8e` 报 1499 字符 ↔ 语料 1499 ✅，`mem_5a7f779a` 报 1403 ↔ 1403 ✅。

### 「Karpathy 模块」——白板即语料：把记忆流程图直接喂给 AI

这条线的起点是一句原话：**「dsh graph 正是我想要的 Karpathy 模块」**。它要解决的不是"检索得准不准"，而是**记忆的形态**：传统 RAG 每次查询都从零重新发现，没有知识积累；Karpathy 式的做法是让模型渐进维护一个持久 wiki（实体页 / 概念页 / 交叉引用 / 矛盾标注），靠 `index.md` + `log.md` 导航。

本仓的落地不是"再写一套 wiki"，而是找到了一个**零新机制**的接口——**页面即语料（S10.1）**：

> **白板卡片带锚点，凭锚点被 Tier-0 目录切条**——切分顺序是「锚点 → 标题 → 顶层条目 → 整文件兜底」，所以带锚点的卡片会作为独立条目进入**每轮注入的指引层**，不需要任何新管线。

```markdown
### 卡片标题
<!-- memory:mem_<32hex> -->
```

**锚点怎么算（内容寻址，可复算）**：
`mem_` + `sha256(workspaceKey + '\0' + 页面相对路径 + '\0' + 卡片标题)` 的前 32 位十六进制。
白板文本作为**五个来源之一**（`user` / `project` / `log` / `whiteboard` / `reflection`）进入 Tier-0 目录，并有**保底配额**（`whiteboard` 与 `user` 各保底 `floorRatio·maxTokens`）——防止 `project` 层把 800 token 全占、白板一条都进不来。

> **⚠️ 实现边界（如实标注，不夸大）**：锚点→语料这条目前**只打通了「注入」路径**（Tier-0 目录，`index.js` 的 `add('whiteboard', …)`）。
> **`memory_recall` 的检索语料目前仍只含四类**——日志 / 反思 / 项目笔记 / 用户级记忆，**白板尚未接入**（见 `lib/index.js` 中 `pushL0` 的四个调用点与 `semSources` 的四个来源）。
> 也就是说：白板内容**每轮会被注入**，但**主动 `memory_recall` 还搜不到它**。这是契约层已定、实现待补的一项缺口，不在本轮改动范围内。

这个设计的收益是双向的：
- **看板/白板不再只是"给人看的视图"**，它同时是**注入语料的来源**——你在看板上记下的目标、判据、结论，AI 下一轮就能在指引层看到；
- **顺带缓解"双状态源"**：内容只有白板一份，指引层是它的派生，不会出现"白板说 A、索引说 B"。

**Karpathy 式 wiki 的六条落地**（S10.1–S10.6）：

| 条款 | 做什么 |
|---|---|
| **S10.1 页面即语料** | 白板卡片带锚点 ⇒ 被 Tier-0 指引层切条并每轮注入（**检索侧尚未接入，见上方边界说明**） |
| **S10.2 索引自动生成** | `index` 由页面**派生**（链接 + 一句话 + `layer`/`status`），与白板**不得各写一份**；派生结果须与 Tier-0 目录条目一致 |
| **S10.3 lint 补齐** | 零 token 四类：孤立条目 / 陈旧 / 被提及却无独立页 / 缺交叉引用。**只有"矛盾检测"需要 LLM，且必须用户点一下才跑，不得进自动路径**；lint **只报告不自动改** |
| **S10.4 不建状态机** | 白板是**视图层**；状态归记忆条目的 `layer` + `status`。新增状态机 = 违规 |
| **S10.5 答案归档回流** | 一次检索/分析的结论必须能**一键**沉淀为：① 白板新卡（带锚点）② 记忆条目 ③ handoff 账本一条。**任何"只活在对话里"的结论都算流程不合格** |
| **S10.6 人机分区** | `<!-- model -->` / `<!-- user -->` 分区，整篇重写必须原样带回用户段——**模型重写后用户段逐字节保留** |

**顺序纪律（踩过的坑）**：**契约层（格式 / 锚点 / 索引派生）必须先于 RAG 底层**——它决定语料形状；先做 RAG 就得对语料重做一遍。界面层（看板渲染 / 交互）反而排在 RAG 之后，"它只是视图"。

**被明确否决的路线**：Grep agentic（"模型驱动 glob/grep 打败一切"）。前提是**每轮多轮 LLM 工具调用**（token 乘数）且语料**精确 token 可匹配**——而自然语言记忆没有可 grep 的字面。只吸收了那句「要不要搜由智能判断」，**默认判断交给本地线性分类器 fv2（0 token）**。

### 唤起度：判断"该不该想起"，而不是"有多像"

这是整个系统最技术、也最容易被误解的一点。**语义相关 ≠ 唤起必要**——材料与当前话题很像，不代表现在注入它有帮助。我们把决策拆成两个可分别度量的目标：**语义相关性**与**唤起必要性**。

**发现并命名的失效模式：回声陷阱（echo trap）**。
当用户复述了某条记忆（"你说过 X 对吧"），该记忆的语义分**必然很高**——但此时注入它是冗余的。在 86 条人工金标上的实测分布：suppress 类的最高分（面条回声 **0.6507** 及其变体 0.6254）**超过全部 activate 正例（max 0.5914）**。也就是说——**"看起来最安全"的阈值，恰好稳定地踩中回声**。

**回声的双臂规则**：回声 = 「查询与 top-1 候选构成近重复复述」∧「陈述句式」∧「无回忆意图」。
词面臂（bigram containment ≥ θ）与语义臂（`denseTop ≥ 0.75`）**取或**——任一单臂都被证伪不足，组合后在 86 gold 上零漏报零误报。

**三条被证伪的捷径**（写进论文的负面结果）：
1. 词面覆盖率**单独不可判**回声——echo-suppress 组的 containment 中位数（0.273）反而**低于** activate 组（0.462），因为问句天然共享目标术语；
2. 纯文本三分类**不可判**必要性（macroF1 0.494）；
3. **全局前置回声否决会误伤显式追问**——把它从全局前置移入 proactive lane 后，同一数据最优格由 precision 0.818 / recall 0.237 / 越界 1 改善为 **1.000 / 0.289 / 越界 0**。

**校准与特征权重**（可直接复现的数字）：
- sigmoid 校准把意图头准确率 **0.744 → 0.872**、Brier **0.227 → 0.131**（58 gold）；
- 可部署特征集的 LR 系数：`mark`(疑问/回忆标记) **+1.64** ≫ `containment` **+0.94** > `intentProb` **+0.58** > `margin` **+0.27** ≫ `denseTop` **−0.38**。
- **结论一句话**：「**是否在问**」比「**有多像**」重要一个数量级。

### 三级部署：体积—质量曲线（都实测过）

| 层 | 体积 | 运行时 | L2 R@5 | 定位 |
|---|---|---|---|---|
| 词法 BM25（`lexical_pre_v2`） | **0** | 纯 JS | 0.200 | 人人可用的基础层与最终回退 |
| **JS 标准语义层**（transformers.js + `multilingual-e5-small` q8） | ~**130MB** | Node 内 ONNX | **0.850** | npm 安装即得的标准层 |
| **Python 进阶层**（BGE-M3 int8 ONNX 563MB / fp32 2.3GB） | 二档可选 | sidecar | **0.925** | 效果冠军，向导按需启用 |

JS 层关键数字：模型加载 **679ms**、查询编码 **3.8ms**、251 条全库重建 **5.5s**。
int8 关键数字：与 fp32 同口径 head-to-head **R@5 delta = 0.000**、MRR 差 0.007（噪声级）、向量余弦均值 0.975、编码提速 **6×**（44s vs 262s）、单查询 p50 **16ms**。
⇒ **量化损失在排序意义上为零**，所以 563MB 档可作为 fp32 的默认替代。
e5-small 与 BGE-M3 的差距（0.85 vs 0.925）集中在 hard-negative 双子对——小模型仍显著优于纯词法（**+65pt**），但对抗式近邻区分是**容量问题，不是协议问题**。

> 全部结论来自可复现实验并冻结为工程决策台账（D1–D11）：[检索选型研究](docs/M7-RESEARCH-PAPER.md) · [激活策略 v2 技术报告](docs/M7-ACTIVATION-V2-PAPER.md) · [嵌入基准](docs/M7-EMBEDDING-BENCHMARK.md) · [Held-out 人工金标验收](docs/M7-ACTIVATION-V2-HOLDEDOUT-EVAL.md)（67 条人工打分：actPrecision **0.917** / 有害注入 **0** / echo 层 **7/7**）。

---

## 她怎么提醒

**日历是她替你维护的。** 对话里出现截止日期和约定，她自动记下（`calendar_add`）；**没完成的事会持续注入后续会话，直到完成**——约定不会被忘在某个聊天记录的深处。日视图铺开 07:00–22:00 时间轴，地点、提醒、紧急度语义色，一眼看清今天；`calendar_list` / `calendar_done` / `calendar_remove` 让她汇报、销账、撤销。

按时段的问候：清晨、午后、深夜，问候语会提起你当天最重要的工作——不是模板寒暄，是读过你日志的问候。

离开超过一小时再回来，记忆面板自动打开，一句"欢迎回来"，附上你不在时该知道的近期摘要。不喜欢被打扰？「自动弹出记忆窗口」一个开关，说关就关。

---

## 她怎么长大

**蒸馏：把过程流水换成可复用的结论。** 30 天前的每日日志交给她通读，只提炼有跨会话长期价值的要点——技术决策、架构约定、偏好、踩过的坑——写进项目笔记；原文归档保底，AI 不可用时降级为原样归档，**绝不丢一个字**。召回边界同样清楚：技能、用户级、项目笔记永不参与蒸馏——蒸馏只处理日期命名的流水，动不了的从来不动。

**技能：像骑自行车，不用想怎么骑。** 人学会骑车之后就不再回忆教学步骤——肌肉记忆接管一切。她也一样：多次观察到你的纠正、或反复做着同类的事，流程就固化成技能；下次遇到相似的活儿，不用谁提醒，checklist 自动附上。注入形态分三级——完整步骤 / 摘要 / 仅提示，高风险场景自动降级为提示，不添乱。技能由跨会话证据渐进晋升，在「记忆中枢」页签审批；90 天没用自动归档，重要的可置顶，常用的会被轻轻保活。

**反思：每天合上账本前，她给自己写复盘。** 成果、教训、下一步，落在独立的反思层；第二天第一次会话，主动呈现昨天的反思——你的项目从周一开始就有了一个记得昨天所有事的人。

---

## 她怎么交接

> 交接默认开启——水位阈值定在 0.75，恰好压在宿主 0.80 自动压缩线之下。窗口大小自动取自当前模型（settings.yaml 的 contextWindow，如 1M），也可手动覆盖。

上下文将满时，她不再把整本书烧成一句读后感，而是写下**四段式交接笔记**——任务状态、目标、已试过的方案与失败原因、进度与下一步——合上这个窗口，翻开下一个。写不进笔记的也不怕：完整的历史消息与工具输出落进本地归档，随时可搜，细节不再死在火里。

她还能主动翻回去：`memory_search` 按需检索全量归档，`memory_note` 随手记下要紧事——从"被动吃注入"到"自己查资料"，这是她记性的第二次升级。

配 token 水位感知：快满时，她提示你开新窗口交接，而不是默默压缩。窗口是宿主的领地——她只助产交接，从不越权替宿主做决定。

### 交接为什么不是"写一段摘要"——白板与账本的工程

**问题**：让 LLM 生成一段"之前的进展"交给新窗口，看起来简单，实际会退化——每次压缩都丢一层，几轮之后交接材料与真实状态脱节，而**没人能发现它脱节了**。所以这里的做法是：**交接材料也不能自说自话，它得是可追溯、可判定、可回归的**。

三件实体，各管一段：

| 实体 | 是什么 | 落盘位置 |
|---|---|---|
| **交接账本**（handoff） | 固定**四段式**：任务状态 / 目标 / 已试方案与失败原因 / 进度与下一步 | `handoff/handoff-*.md` |
| **白板**（PLAN.md） | 项目**全貌图**：人能读的规划快照，改版时旧版自动归档 | `handoff/PLAN.md` |
| **锚点**（memory anchor） | 每条记录带 `<!-- memory:mem_<32hex> -->`，**身份寻址**而非位置寻址 | 记忆文件内 |

**两条关键工程约束**：
1. **账本质量是硬门，不是文风建议**。四段标题必须**逐字匹配**（标题错会让后续的权重化截断失效、注入端解析失败），每段有最小长度，写好直接拒收——本节开头那段「任务状态 / 目标 / 已试方案与失败原因 / 进度与下一步」就是被这个门塑形的结果。
2. **锚点让追加写入不会击穿文件**。`appendAnchoredRecord()` 在写入前先解析既有文件：**非 clean 状态一律 fail closed**（既不追加也不改写）；正文里一旦出现保留语法，**写入当场被拒并报出行号**——而不是写入"成功"、从下一次开始整个文件永久拒写。

**看板**（Kanban / 泳道图）不是另做一个 UI，而是**同一批账本与白板的另一种视图**：把账本条目按泳道（目标 / 进行中 / 失败与弯路 / 归档）铺成矩阵。

> 一个真实的踩坑记录：看板 v1 曾把 92 个文件压成 92 张卡、三条泳道恒空——**根因不是"卡太少"，而是切分粒度错了一个层级**（按文件切，而不是按内容里的小节切），外加 `sectionOf` 循环缺 `break` 导致整篇归一到最后一个标题。v2 才把粒度对齐到「小节」。

**主视觉与子代理的边界**：跨窗口续命的细节在 `docs/internal/` —— [三层契约](docs/internal/THREE-LAYER-CONTRACT.md)（Tier 0/1/2 的预算与验收判据）、[语义架构规范](docs/internal/SEMANTIC-ARCHITECTURE-SPEC.md)（条款 S1–S10 与阶段门）、[RAG + Karpathy 攻关细则](docs/internal/RAG-KARPATHY-PROGRAM.md)（六步链路 × 三条阶段线的施工图）。

---

## 她怎么搬家

你的记忆不止在一家 AI 里。WorkBuddy、CodeBuddy、Claude Code、Codex——她在本机扫描这些工具留下的历史会话与记忆，逐源列出、逐源勾选导入。「接续」页签是这场迁徙的口岸：**只存路径指针，不复制内容**——尊重来源，零冗余；不想要了，按源删除，干净利落。

导入侧和注入侧各设一道卫生闸门：外部工具的脏数据、别家的画像残留，进不来，也出不去。**搬家归搬家，家具先消毒。**

---

## 她怎么让你放心

**每一次想起都可查账。** 每个"要不要激活"的决策都带完整证据链；「唤起回顾」页签把每次投递摊开：投给了谁、何时、结果如何——按 A 该激活 / P 只预取 / S 应抑制 / H 有害 / E 改目标五档复核打分，判定队列自动汇总成政策提示。她的记性经得起审计。

**每一句话进来都过门禁。** 三个写入工具全部执行写前体检：GBK 乱码（34 项特征全表）、复读退化、连续重复行、外部 AI 画像 JSON 特征、base64 残留——一律拒写，并给一句中文回执告诉你为什么。追加单条 8000 字、全量改写 20 万字上限；写入前与文件尾部近 60 行比对去重。

**体检不止防外来物。** 设置 → 调试中心，「扫描脏 token」一键扫过用户级、项目笔记、日志、反思，按行区间报告问题——只报位置，不看内容。

最后是边界，写成性格：

1. 不替宿主决定压缩——窗口是宿主的领地，她只负责交接；
2. 不上传任何记忆——全部存储在你本机，外部扫描只读；
3. 不用记忆操纵你的语体——注入永远声明"背景事实，非表达示范"；
4. 不做黑箱——每条记忆证据直达，每次投递可回放；
5. 不做全家桶——只做记忆，边界清晰才可信。

---

## 她怎么听话

**一切皆开关。** 首次启动自动播放**欢迎向导**：每步一枚 Office/Fluent 式液态玻璃应用图标——注入青蓝、问候暖金、日历青绿、引擎紫蓝、雷达天青、完成珊瑚金——各配专属循环动效（铃摆、翻页、双环、棱镜、雷达、火花）。每个功能当场开关、立即生效，不用再进设置页确认；语义引擎的检测、下载、自检内联在向导里一次完成；外部记忆来源实时扫描、逐源勾选。中途关掉也不慌——最后一步"完成提醒"告诉你每个开关住在设置的哪个分区。

<p align="center"><img width="720" alt="welcome tour" src="docs/screenshots/tour-welcome.png"></p>

<p align="center"><img width="720" alt="tour core" src="docs/screenshots/tour-core.png"></p>

升级用户的一次性触达：v0.1.30 起所有用户升级后都会自动播放一次完整向导，结束后自动接更新日志（可点击跳过）。之后可随时在 **设置 → 外观 → 欢迎向导 → ▶ 重看引导** 重新打开。

设置页与向导双入口、一一对应：自动联想、周期快照、暂离问候、夜间托管、每日反思、定时总结、外部记忆、技能固化、自动弹出……每个开关一行中文说明，中英文界面随心切换，面板字号可调。

十二个页签，各司其职：**概览**（暂离问候 + 时段总结）、**日志**（含用户级硬约束编辑器）、**唤起回顾**（查账，每次激活可打分）、**记忆中枢**（三层记忆店 + 技能审批）、**存储管理**、**笔记**、**白板**、**反思**、**接续**（外部记忆）、**日历**、**检索**、**工作区**（关系图）。面板也体贴：DSH Desktop 增强模式（透明/Mica 材质）下自动保住可读性；默认位置不挡侧边栏「记忆」入口；点外部或按 Esc 就走——在场，但不碍事。

**长跑批处理？开无人值守。** 设置 → 自动化提供「无人值守模式」与「夜间自动托管」（22:00–08:00 可调）：托管期间不注入欢迎语、不寒暄、不下行为指令，日历提醒同步静默——模型专注干活，token 花在正事上。

**升级也体面。** 设置页「检查更新」比对 npm registry，registry 安装一键更新；大版本更新日志配玻璃 Logo 开场动画——三层组装、展开、消散，点击任意处可跳过。

---

## 安装（一条命令）

> 前置：安装 [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) 并至少启动过一次 `dsh web`。

在 **profile 目录**（`~/.dsh/profiles/web`）执行：

```bash
cd ~/.dsh/profiles/web
pnpm add @a9i5k4/dsh-auto-memory@latest
```

然后编辑同目录 `package.json`，在 `dsh.profile.bundles` 数组追加：

```json
"@a9i5k4/dsh-auto-memory"
```

重启 **dsh web** 生效（侧边栏出现「记忆」入口）。

> 没有 pnpm？`npm install @a9i5k4/dsh-auto-memory@latest` 同样可用。
> pnpm v11 限制安装发布不足 1 天的版本：当天发布想立即更新，在 profile 目录 `pnpm-workspace.yaml` 加 `minimumReleaseAge: 0`，或装显式版本。

### 语义引擎（可选但推荐）

内置 JS 语义档（e5-small q8 ~130MB）需要推理库 `@huggingface/transformers`（随主包作为可选依赖自动安装）。若 pnpm 因安全策略拦截原生脚本（提示 `ERR_PNPM_IGNORED_BUILDS` / `Ignored build scripts: onnxruntime-node, sharp`），执行一次批准后重装即可：

```bash
# 批准 onnxruntime-node / sharp 的原生安装脚本,再重装 transformers
pnpm approve-builds
pnpm add @huggingface/transformers
```

装完重启 `dsh web`，向导的语义引擎步会自动检测到就绪（SHA256 校验 + 推理自检）。

三档检索引擎，在 设置 → 自动记忆引擎 里切换：

- **词法（C1，0GB）** —— 永远在线的保底，对全文做 BM25。
- **内置语义（C2，约 130MB）** —— 默认档，首次启动自动下载；检索是分层的（L0 摘要 + rank-space 融合），长记忆不再因模型 token 上限被截断。
- **高级 Python（C3，约 563MB）** —— BGE-M3，面向深度用户；在同一设置步里安装后，`memory_recall` 同样会用到它（不只是主动联想）。

检索还带时间感知：问「上周」或「三天前」，命中的记忆会浮到前面。词法检索 0GB 永远兜底，不装也能用（仅召回精度较低）。

### AI 时代安装法

复制下面这段发给你正在用的 AI 助手即可：

```text
在 DeepSeek Harness web profile 目录 ~/.dsh/profiles/web 安装 npm 包
@a9i5k4/dsh-auto-memory（pnpm add 或 npm install），
把 "@a9i5k4/dsh-auto-memory" 追加到 package.json 的 dsh.profile.bundles 数组，
然后重启 dsh web 激活插件。
```

### 更新

```bash
cd ~/.dsh/profiles/web && pnpm up @a9i5k4/dsh-auto-memory@latest
```

设置页「检查更新」可比对 npm registry 最新版，registry 安装支持一键更新。

---

## 配置

配置文件 `~/.dsh/dsh-auto-memory.json`（GUI 设置页可视化调整，含中英文界面与面板字号）：

```json
{
  "userMemoryDir": "~/.dsh/memory",
  "memoryRoot": "~/.dsh/memory/workspaces",
  "injectEnabled": true,
  "injectBudgetChars": 2400,
  "recentDaysInjected": 1,
  "reflectEnabled": true,
  "autoConsolidate": true,
  "autoConsolidateCooldownMinutes": 30,
  "autoConsolidateDailyMax": 8,
  "unattendedMode": false,
  "unattendedAuto": false,
  "unattendedAutoHours": ["22:00-08:00"],
  "memoryHubEnabled": true,
  "externalSources": { "workbuddy-user": true, "claude-global": true },
  "dayBoundaryMinutes": 450
}
```

> 完整键位见设置页——每个开关都有中文说明；欢迎向导里的每个开关与设置页一一对应。

---

## 工程内核（保持克制的设计）

- **零运行时依赖**：Node 内建模块之外无任何依赖
- **前缀缓存友好**：注入内容字节级稳定，DeepSeek 前缀缓存持续命中，不反复重编码历史
- **限额 AI**：自动沉淀每日 ≤8 次、30 分钟冷却，动态注入默认预算 2400 字符——记忆有用，但不烧预算
- **集中式存储**：全部工作区记忆收在 `~/.dsh/memory/workspaces/` 一个根下，任意会话可读
- **30 天蒸馏**：旧日志由 AI 蒸馏进项目笔记，原文归档不丢失

### 3.0 底层重建（用户看不见，但每次唤起都经过它）

这一版的大部分工作不产生新按钮——它们改的是"记忆凭什么被相信"。八项底层机制全部落地并实测：

| 机制 | 解决的问题 |
|---|---|
| **写入侧门禁** | 保留语法过滤前移到**写入原语**（而非事后检测）。含保留标记的正文会被当场拒绝并给出**行号**，不再出现"一条脏正文让整个文件永久拒写" |
| **判据账本** | 每次「要不要唤起」的决策落成可复核的账本条目，五档评分（A/P/S/H/E）回流成策略——不是日志，是**可审计的判据链** |
| **状态单源提交** | 记忆索引版本（miv）收敛到单一来源，消除"同一个库两个版本号"导致的重算与漏判 |
| **并发原子写** | Windows 下 `rename` 遇外部句柄占用会抛 `EPERM`——现在带退避重试，且失败时**保全完整候选快照**（`recoveryPath`）供人工取证，不再把已渲染好的内容一起销毁 |
| **引擎身份门** | JS 与 Python 两套语义实现**身份互斥**：选了谁就是谁，绝不互相顶替、不互相联动 |
| **真增量嵌入** | 只对变化的记录重新嵌入并复用顺序，而不是整库重算 |
| **精排有界窗口** | 可选精排档位（off/fast/enthusiast），入队起算 60s 到期不续命、LRU ≤16、忙则让路——后台重活永远不拖慢当前对话 |
| **多工作区 / 多会话隔离** | 同时开多个工作区、多个会话时，各自的唤起判据、索引缓存、降级状态**互不覆盖**——你点进哪个工作区，都不影响正在跑的那个 |

> 这八项都带回归套件与变异演示（把机制改回旧行为，测试必须真红）。工程细节见 [`docs/internal/`](docs/internal/)。

---

## 界面速览

### 记忆面板 · 概览（暂离问候 + AI 时段总结）

<img width="480" alt="overview" src="docs/screenshots/panel-overview.png">

### 记忆中枢 · 三层记忆店与技能晋升审批

<img width="480" alt="hub" src="docs/screenshots/panel-hub.png">

### 唤起回顾 · 每次激活决策可打分

<img width="720" alt="refine" src="docs/screenshots/panel-refine.png">

### 欢迎向导 · 功能开关与引擎检测

<img width="720" alt="tour" src="docs/screenshots/tour-toggles.png">

<details>
<summary><b>更多截图</b>（点击展开）</summary>

### 外部记忆扫描（欢迎向导内）

<img width="720" alt="external scan" src="docs/screenshots/tour-external.png">

### 连接其他 AI 工具

<img width="480" alt="connect" src="docs/screenshots/connect-zh.png">

### 日历视图

<img width="480" alt="calendar" src="docs/screenshots/calendar-zh.png">

### 工作区关系图

<img width="480" alt="workspace map" src="docs/screenshots/workspace-map-zh.png">

### 设置页

<img width="480" alt="settings" src="docs/screenshots/settings-zh.png">
<img width="480" alt="settings 2" src="docs/screenshots/settings-2-zh.png">

</details>

---

## 结构

- `lib/index.js` — Host 半：引擎、注入、工具、路由（零运行时依赖）
- `lib/client.js` — Browser 半：记忆面板（含日历/关系图）+ 设置页 + 欢迎向导（内置中英 i18n）
- `python/` — 可选 Python 语义 sidecar（BGE-M3 int8，进阶档）
- `cordis.patch.yml` — 插件注册行

## 系统架构

全部里程碑已实现并 live verified。完整交互式架构图见 [docs/proactive-associative-memory-system-map.html](docs/proactive-associative-memory-system-map.html)，核心分层如下：

```
DeepSeek Harness (Node, 127.0.0.1:3080)
├─ JS 记忆核心（lib/*_pre.js，零运行时依赖）
│   M1 会话隔离 · M2 ContextObserver 投影
│   M3 记忆锚定（anchored records + sidecar 身份）
│   M4 语料适配 + 影子检索宿主（evidence store）
│   M5 上下文/证据桥（envelope · coverage · cite/correction）
│   M6 激活收件箱（校验→offer→claim→参考尾注渲染→delivered/seen）
│   lexical_pre_v2 词法回退检索（BM25 + CJK 2gram，0GB 永远可用）
│   C2 内置语义层（e5-small q8 ~130MB，默认档）
└─ Python sidecar M7（可选，lazy spawn 子进程）
    worker_semantic_pre_v1.py
    ├─ index_sync：JS 授权分页建库（digest 校验，scope 分组）
    ├─ dense：BGE-M3 int8 + para-512 分块 + 余弦检索（R@5 0.925）
    ├─ hybrid：稠密 0.7 + 词法 0.3 融合
    └─ fv2 激活决策：两车道 + 硬门禁（echo/correction/stale/scope）
```

**权限分立**：Python（语义层）决定"想起什么、何时建议"；JS（权威层）决定身份、授权、时序、投递——Python 不创建证据，也不直接注入。数据流：`context_push → M5 envelope → 决策 → M6 固定边界注入 → delivered/seen 证据回流`。

### 技术论文与设计文献

本项目的设计不是拍脑袋——每项算法结论都来自可复现实验，并冻结为工程决策台账：

| 文献 | 内容 |
|---|---|
| [多语言嵌入式检索选型研究](docs/M7-RESEARCH-PAPER.md) | 3 模型 × 5 分块策略 × 6 检索通道 ≈ 90 评测单元；BGE-M3 全面领先，冻结为 D1–D11 工程决策 |
| [激活策略 v2：回声陷阱的发现、度量与修正](docs/M7-ACTIVATION-V2-PAPER.md) | 语义相关 ≠ 唤起必要的激活策略技术报告 + 双轨部署架构（§7） |
| [嵌入基准报告](docs/M7-EMBEDDING-BENCHMARK.md) | 模型/分块/融合的冻结依据：bge-m3 + para-512-noov + 加权融合 |
| [算法冻结决策 D1–D11](docs/M7-ALGORITHM-DECISION.md) | 全部研究结论到生产实现的决策台账 |
| [Held-out 人工金标验收](docs/M7-ACTIVATION-V2-HOLDEDOUT-EVAL.md) | 67 条人工标注打分：actPrecision 0.917 / 有害注入 0 / echo 层 7/7 |
| [Python Sidecar 完整契约](docs/PYTHON-SIDECAR-CONTRACT.md) | 协议/生命周期/权威边界/各里程碑回归证据 |

论文由自主工程 Agent（ZCode / GLM）撰写，全部结论在人类审核下冻结进生产实现。

### 项目文档

| 文档 | 回答什么 |
|---|---|
| [**白皮书**](docs/WHITEPAPER.md) | 「有哪些**不能违反**的约束、哪些已知边界」——文中每个默认值都经代码自核 |
| [**前端共创计划**](docs/FRONTEND-CO-CREATION.md) | 外部贡献者能改什么、什么是禁区、怎么改——含完整组件/路由/插槽地图 |
| [功能全量清单](docs/internal/FEATURE-INVENTORY.md) | 「有哪些功能、各住在哪」（39 条用户能力 / 19 工具 / 67 路由 / 138 配置键） |

> **⚠️ 从 3.0 之前升级上来的用户请注意**：3.0.0 有一批默认值**被翻转**——
> 其中最重要的是白板 + 账本从「默认关」改为 **「默认开」**。
> 3.0 之前的文档在默认值上都不可信，请以[白皮书 §4.1](docs/WHITEPAPER.md) 的核验表为准。

## 已知限制

- 记忆文件为纯文本 Markdown；除非明确要求，不存储密钥
- `memory_recall` 会话搜索依赖已部署的 session-query 索引，缺失时仅本地检索可用
- 高级 Python（C3）召回需先在 设置 → 自动记忆引擎 安装 BGE-M3 模型（约 563MB）
- 词法检索为全量扫描、无倒排索引，记忆上千条后才需优化
- `autoConsolidateCooldownMinutes = 0` 会回退为 30（已知瑕疵，后续版本处理）
- 插件增减需要重启 dsh 生效

---

## 社区致谢

**反馈与交流：**欢迎加入 QQ 交流群——[点击加入 dsh-auto-memory 交流群](https://qm.qq.com/q/v7Asxn6vPa)——问题反馈、使用技巧交流，响应比 issue 更快。

社区贡献者：

- [@Minervaowl7](https://github.com/Minervaowl7) — **负责新版前端（开发版 UI）的完整开发**：参考图风格记忆工作台（九页导航、列表与详情、四组设置、专注查看、深色适配、窄屏导航），以生成器方式接入——新皮肤版本从经典组件派生，上游结构漂移即明确报错（[PR #146](https://github.com/Aik358/dsh-auto-memory/pull/146)）。同时也是贡献最活跃的贡献者：51 个 PR + 57 个 issue，覆盖工作区概览日志日期锚定、自动续跑宿主加固、语义索引自愈、python 下载链路、恢复候选生命周期等（[#16](https://github.com/Aik358/dsh-auto-memory/issues/16)–[#146](https://github.com/Aik358/dsh-auto-memory/pull/146)）
- [@JIE42393](https://github.com/JIE42393) — 7 个 issue，覆盖面板行为、召回质量与配置边界（[#15](https://github.com/Aik358/dsh-auto-memory/issues/15)、[#26](https://github.com/Aik358/dsh-auto-memory/issues/26)、[#30](https://github.com/Aik358/dsh-auto-memory/issues/30)、[#41](https://github.com/Aik358/dsh-auto-memory/issues/41)–[#43](https://github.com/Aik358/dsh-auto-memory/issues/43)、[#45](https://github.com/Aik358/dsh-auto-memory/issues/45)）
- [@Fishsb](https://github.com/Fishsb) — 3 个 issue，关于记忆召回与注入行为（[#18](https://github.com/Aik358/dsh-auto-memory/issues/18)–[#20](https://github.com/Aik358/dsh-auto-memory/issues/20)）
- [@messiahyl](https://github.com/messiahyl) — 2 个 issue（[#8](https://github.com/Aik358/dsh-auto-memory/issues/8)、[#9](https://github.com/Aik358/dsh-auto-memory/issues/9)）
- [@ProperSAMA](https://github.com/ProperSAMA) — DSH Desktop 增强模式（透明/Mica 材质）面板可读性修复 + 入口按钮防遮挡与外点/Esc 关闭（[PR #12](https://github.com/Aik358/dsh-auto-memory/pull/12)）
- [@nkh0472](https://github.com/nkh0472) — 无人值守/批处理场景加固反馈，推动了欢迎向导与功能开关化（[Issue #10](https://github.com/Aik358/dsh-auto-memory/issues/10)）
- [@fei009009](https://github.com/fei009009) — 提交 PR（[#29](https://github.com/Aik358/dsh-auto-memory/pull/29)）
- [@humou44](https://github.com/humou44) — 日文界面本地化：[PR #143](https://github.com/Aik358/dsh-auto-memory/pull/143) 提出，已并入主线并扩展为**字典查表式** i18n 层，覆盖整个面板（602 条内联文案 + 583 条词典条目）；后续语言沿用同一层接入
- [@alexchenzl](https://github.com/alexchenzl)（[#6](https://github.com/Aik358/dsh-auto-memory/issues/6)）· [@ALuoXue](https://github.com/ALuoXue)（[#2](https://github.com/Aik358/dsh-auto-memory/issues/2)）· [@Architectxz](https://github.com/Architectxz)（[#1](https://github.com/Aik358/dsh-auto-memory/issues/1)）· [@cuohua](https://github.com/cuohua)（[#40](https://github.com/Aik358/dsh-auto-memory/issues/40)）· [@eclgo](https://github.com/eclgo)（[#13](https://github.com/Aik358/dsh-auto-memory/issues/13)）· [@jeffsui](https://github.com/jeffsui)（[#39](https://github.com/Aik358/dsh-auto-memory/issues/39)）· [@lhbsaa](https://github.com/lhbsaa)（[#3](https://github.com/Aik358/dsh-auto-memory/issues/3)）· [@moonltppt](https://github.com/moonltppt)（[#14](https://github.com/Aik358/dsh-auto-memory/issues/14)）· [@swtseaman](https://github.com/swtseaman)（[#21](https://github.com/Aik358/dsh-auto-memory/issues/21)）· [@xiaochaZ](https://github.com/xiaochaZ)（[#38](https://github.com/Aik358/dsh-auto-memory/issues/38)）· [@zjj871114037](https://github.com/zjj871114037)（[#7](https://github.com/Aik358/dsh-auto-memory/issues/7)）— 问题反馈与功能建议

完整名单（含基础设施赞助）：**[贡献者与赞助](https://htmlpreview.github.io/?https://github.com/Aik358/dsh-auto-memory/blob/main/docs/CONTRIBUTORS.html)**

---

## 赞助

本项目部分开发资源由以下方提供：

- **[DSH API](https://api.dshapi.icu/register?aff=HJU27P7JL39N)** — API 中转站，为本项目的开发、测试以及 M 系列语义引擎研究提供模型端点。感谢一路同行。

基础设施与 API 额度赞助方列在 **[贡献者与赞助](https://htmlpreview.github.io/?https://github.com/Aik358/dsh-auto-memory/blob/main/docs/CONTRIBUTORS.html)** 页面。如希望支持本项目，欢迎提 issue 或加入 QQ 交流群。

---

## 制作署名

本项目由人与 AI 协作完成。除上述工程与社区贡献外：

- **Aik358** — 项目所有者：产品方向、架构与工程决策。
- **[@Minervaowl7](https://github.com/Minervaowl7)** — **新款前端（皮肤系统）的作者**：独立完成了新版界面的完整开发——九页工作台、列表/详情、四组设置、专注查看、深色适配与窄屏布局。**这是本插件皮肤体系的起点与基础**：他以「生成器从经典组件派生新皮肤版本」的方式接入，使后来者可以在此之上继续换装，而经典档保持零改动。同时他也是本项目贡献量最大的社区开发者（51 PR · 57 issue）。
- **ZCode（GLM，智谱 Z.ai）** — 自主工程 Agent：M 系列语义引擎实现、两篇基准研究论文（[M7 检索选型研究](docs/M7-RESEARCH-PAPER.md) / [激活策略 v2 技术报告](docs/M7-ACTIVATION-V2-PAPER.md)）、全套回归测试、宣传网页设计与构建。
- **Kimi K3（月之暗面）** — 前端 Agent：参与 v0.1.30 欢迎向导界面资产与视觉验收。
- **DeepSeek Harness（DeepSeek V4）** — **本项目的自我迭代环境与协作者**：上述社区作者与 Agent 的多数功能，都是**在 DeepSeek Harness 里、与 DeepSeek V4 一起自进化出来的**——发现问题、定位根因、写补丁、跑回归、开 PR，全过程发生在同一套 Harness 会话中。这本身即是一次「**Harness 自我迭代、自我开发**」的实例：项目一边被人和 AI 使用，一边在同一个环境里把自己做得更好。本插件本身的上下文管理能力（交接账本 / 白板 / 水位感知 / 自动接续）也正是为支撑这种长时间、跨会话的自我迭代而生长出来的。

AI Agent 作为研究论文作者与部分实现作者署名，全程在人类审核与指导下工作。

---

## 发布信息

- GitHub: https://github.com/Aik358/dsh-auto-memory
- npm: `@a9i5k4/dsh-auto-memory`
- License: BSD-3-Clause
- 更新日志：[CHANGELOG.md](./CHANGELOG.md)
