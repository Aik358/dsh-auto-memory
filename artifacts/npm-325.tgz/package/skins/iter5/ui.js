    // Source embedded by tools/build-iter5-skin.mjs inside the host React factory.
    var ITER5_PAGES = [
      ['home', '工作台', 'Workbench', 'blue', 'overview'],
      ['library', '记忆库', 'Memory', 'indigo', 'logs'],
      ['handoff', '接续', 'Continue', 'cyan', 'plan'],
      ['calendar', '日程', 'Calendar', 'orange', 'calendar'],
      ['skills', '技能', 'Skills', 'green', 'hub'],
      ['recall', '唤起回顾', 'Recall review', 'purple', 'refine'],
      ['mindmap', '工作区关系', 'Workspaces', 'pink', 'workspaces'],
      ['storage', '存储与维护', 'Storage', 'slate', 'storage'],
      ['settings', '设置', 'Settings', 'slate', 'settings'],
    ]
    function iter5Identity() { return String(currentSessionIdClient() || '') + '|' + String(currentWs() || '') }
    // ── 主题三态（2026-09-29 恢复）──────────────────────────────────────────────
    //   合并社区作者版本时，本仓原有的「跟随系统 / 亮色 / 暗色」开关被覆盖丢失，只剩被动的
    //   `useDeepTheme()`（宿主给什么是什么）⇒ 用户看不到也改不了当前档位。此处恢复，并把它
    //   接到**同一个** data-deep 上：
    //     'auto'（默认）= 跟随宿主（宿主 preference=system 时即跟随系统）
    //     'light' / 'dark' = 强制；只覆盖传给 data-deep 的布尔值，
    //   配色仍 100% 由 skin.css 的 [data-deep=true] 驱动 —— 不新增任何配色分支。
    //   存 localStorage['dam-skin-theme']；读写 fail-soft（无 storage ⇒ 'auto'）。
    //   注意：宿主自己渲染的覆盖层（轻面板 / 首次向导）不在本开关范围内，它们跟随宿主主题。
    var ITER5_THEME_KEY = 'dam-skin-theme'
    function iter5ThemeGet() {
      try {
        var v = String(localStorage.getItem(ITER5_THEME_KEY) || '')
        return v === 'light' || v === 'dark' ? v : 'auto'
      } catch (e) { return 'auto' }
    }
    function iter5ThemeSet(v) {
      try {
        if (v === 'light' || v === 'dark') localStorage.setItem(ITER5_THEME_KEY, v)
        else localStorage.removeItem(ITER5_THEME_KEY)
      } catch (e) {}
    }
    function iter5ThemeCycle(v) { return v === 'auto' ? 'light' : v === 'light' ? 'dark' : 'auto' }
    function iter5ThemeLabel(v) { return v === 'light' ? L('亮色', 'Light') : v === 'dark' ? L('暗色', 'Dark') : L('跟随系统', 'Auto') }
    function iter5ThemeIcon(v) { return v === 'light' ? 'sun' : v === 'dark' ? 'moon' : 'contrast' }
    /** 皮肤生效深浅 = 本地档位覆盖宿主档位。皮肤内所有取深/浅的地方都走它，保证一处切换处处一致。 */
    function useIter5Theme() {
      var pref = useState(iter5ThemeGet)
      var hostDeep = useDeepTheme()
      var deep = pref[0] === 'auto' ? hostDeep : pref[0] === 'dark'
      return [pref[0], deep, function (next) { iter5ThemeSet(next); pref[1](next) }]
    }
    function iter5PageForTab(tab) {
      if (['notes', 'logs', 'reflections', 'search'].indexOf(tab) >= 0) return 'library'
      if (tab === 'connect') return 'handoff'
      if (tab === 'team' || tab === 'stats') return tab
      var row = ITER5_PAGES.filter(function (p) { return p[4] === tab })[0]
      return row ? row[0] : 'home'
    }
    function Iter5Icon(props) {
      var paths = {
        spark: 'm12 2 2.6 7.4L22 12l-7.4 2.6L12 22l-2.6-7.4L2 12l7.4-2.6zM20 2v4M18 4h4',
        heart: 'M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8z',
        folder: 'M3 7V4h6l3 3h9v13H3zM3 9h18',
        timeline: 'M12 3a9 9 0 1 1-6.4 2.6M3 3v6h6M12 7v5l3 2',
        pulse: 'M2 12h5l3-8 4 16 3-8h5',
        note: 'M6 3h8l4 4v14H6zM14 3v5h5M9 12h6M9 16h6',
        search: 'M21 21l-5-5M18 10a8 8 0 1 1-16 0 8 8 0 0 1 16 0',
        check: 'm5 12 4 4L19 6M21 12a9 9 0 1 1-5-8',
        home: 'M3 11 12 3l9 8M5 10v11h5v-7h4v7h5V10',
        library: 'M4 4h16v16H4zM8 8h8M8 12h6',
        handoff: 'M7 7h10v10H7zM3 12V3h9M21 12v9h-9M10 14l4-4',
        calendar: 'M4 5h16v16H4zM8 3v4M16 3v4M4 11h16',
        skills: 'm12 3 3 6 6 3-6 3-3 6-3-6-6-3 6-3z',
        recall: 'M4 5h16v12H9l-5 4zM8 9h8M8 13h5',
        mindmap: 'M4 4h5v5H4zM15 15h5v5h-5zM4 15h5v5H4zM6 9v6M9 6h8v9',
        storage: 'M4 5h16v5H4zM4 14h16v5H4zM7 7h2M7 16h2',
        settings: 'M4 6h16M4 12h16M4 18h16M8 3v6M16 9v6M10 15v6',
        sun: 'M12 4V2M12 22v-2M4 12H2M22 12h-2M6 6 4.5 4.5M19.5 19.5 18 18M18 6l1.5-1.5M4.5 19.5 6 18M16 12a4 4 0 1 1-8 0 4 4 0 0 1 8 0',
        moon: 'M20 14.5A8.5 8.5 0 0 1 9.5 4a8.5 8.5 0 1 0 10.5 10.5z',
        contrast: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM12 3v18a9 9 0 0 0 0-18z',
      }
      return h('svg', { width: 20, height: 20, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 1.6, strokeLinecap: 'round', strokeLinejoin: 'round', 'aria-hidden': true }, h('path', { d: paths[props.name] || paths.library }))
    }
    function Iter5Tabs(props) {
      return h('div', { className: 'i5-tabs', role: 'tablist', 'aria-label': props.label }, props.items.map(function (it, idx) {
        var selected = props.value === it[0]
        return h('button', { key: it[0], id: props.id + '-tab-' + it[0], role: 'tab', type: 'button', 'aria-selected': selected, 'aria-controls': props.id + '-panel', tabIndex: selected ? 0 : -1,
          onClick: function () { props.onChange(it[0]) },
          onKeyDown: function (e) {
            var next = e.key === 'Home' ? 0 : e.key === 'End' ? props.items.length - 1 : e.key === 'ArrowRight' ? (idx + 1) % props.items.length : e.key === 'ArrowLeft' ? (idx + props.items.length - 1) % props.items.length : -1
            if (next < 0) return
            e.preventDefault(); props.onChange(props.items[next][0])
            var node = e.currentTarget.parentNode.children[next]; if (node) node.focus()
          } }, it[1], it[2] ? h('span', { className: 'i5-dirty-dot', 'aria-label': L('未保存', 'Unsaved') }) : null)
      }))
    }
    function Iter5Card(props) { return h('section', { className: 'i5-card ' + (props.className || '') }, props.title ? h('h2', { className: 'i5-card-title' }, props.icon ? h('span', { className: 'i5-badge', 'data-hue': props.hue || 'blue' }, h(Iter5Icon, { name: props.icon })) : null, props.title) : null, props.children) }
    function Iter5Error(props) { return h('div', { className: 'i5-error', role: 'alert' }, props.error, props.retry ? h('button', { type: 'button', onClick: props.retry }, L('重试', 'Retry')) : null) }
    // Never accept a response issued for a different session/workspace or an unmounted view.
    function useIter5Data(loader, deps) {
      var pair = useState({ data: null, error: '', loading: true })
      var retry = useState(0)
      var identity = iter5Identity()
      var requestKey = JSON.stringify([identity, retry[0]].concat(deps || []))
      useEffect(function () {
        var alive = true
        pair[1]({ key: requestKey, data: null, error: '', loading: true })
        Promise.resolve().then(loader).then(function (data) {
          if (alive && identity === iter5Identity()) pair[1]({ key: requestKey, data: data, error: '', loading: false })
        }, function (e) {
          if (alive && identity === iter5Identity()) pair[1]({ key: requestKey, data: null, error: String(e && e.message || e), loading: false })
        })
        return function () { alive = false }
      }, [identity, retry[0]].concat(deps || []))
      // Do not show the previous file under a new selection before the effect runs.
      return Object.assign({}, pair[0].key === requestKey ? pair[0] : { data: null, error: '', loading: true }, { retry: function () { retry[1](function (n) { return n + 1 }) } })
    }
    function iter5MemoryRows(list, state) {
      var out = []
      if (state.userFile && list.userSize > 0) out.push({ path: state.userFile, label: L('用户偏好', 'User memory'), kind: 'user', scope: 'user', size: list.userSize })
      if (state.notesPath && list.notesSize > 0) out.push({ path: state.notesPath, label: L('项目笔记', 'Project notes'), kind: 'notes', scope: 'project', size: list.notesSize })
      ;(list.logs || []).forEach(function (r) { out.push({ path: list.projectDir ? list.projectDir + '/' + r.name : r.name, label: r.date || r.name, date: r.date, kind: 'logs', scope: 'project', size: r.size }) })
      ;(list.reflections || []).forEach(function (r) { out.push({ path: (list.projectDir ? list.projectDir + '/' : '') + 'reflections/' + r.name, label: r.date || r.name, date: r.date, kind: 'reflections', scope: 'project', size: r.size }) })
      return out
    }
    async function iter5MemorySnapshot() {
      // /list has no workspace parameter on upstream 3.2.1. Prime the current
      // workspace through /state, then reject any list from a different root.
      var state = await apiGet(API.state, { ws: currentWs() })
      var list = await apiGet(API.list)
      var expected = String(state.notesPath || '').replace(/[\\/][^\\/]+$/, '').replace(/\\/g, '/')
      var actual = String(list.projectDir || '').replace(/\\/g, '/')
      if (expected && actual && expected !== actual) throw Error(L('工作区数据正在切换，请刷新后重试。', 'Workspace data changed. Refresh and try again.'))
      return [list, state]
    }
    function Iter5Browse(props) {
      var rowsData = useIter5Data(iter5MemorySnapshot, [props.nonce])
      var intent = props.intent || {}
      var filter = useState(intent.category || 'all'), scope = useState(intent.scope || 'all'), query = useState(''), selected = useState(intent.path || '')
      var append = useState(false)
      var reader = useRef(null)
      var rows = rowsData.data ? iter5MemoryRows(rowsData.data[0], rowsData.data[1]).filter(function (r) {
        return (filter[0] === 'all' || r.kind === filter[0]) && (scope[0] === 'all' || r.scope === scope[0]) && (r.label + ' ' + r.path).toLowerCase().indexOf(query[0].toLowerCase()) >= 0
      }) : []
      var chosen = rows.filter(function (r) { return r.path === selected[0] })[0] || rows[0]
      var path = chosen && chosen.path || ''
      var file = useIter5Data(function () { return path ? apiGet(API.file, { path: path, ws: currentWs() }) : Promise.resolve(null) }, [path, props.nonce])
      useEffect(function () {
        var el = reader.current, main = el && el.closest('.i5-main')
        if (!main) return
        function fit() {
          var top = el.getBoundingClientRect().top - main.getBoundingClientRect().top + main.scrollTop
          el.style.setProperty('--i5-reading-height', Math.max(260, main.clientHeight - top - 20) + 'px')
        }
        fit()
        var observer = typeof ResizeObserver === 'function' ? new ResizeObserver(fit) : null
        if (observer) {
          observer.observe(main)
          if (main.firstElementChild) observer.observe(main.firstElementChild)
          var toolbar = el.parentElement.previousElementSibling
          if (toolbar) observer.observe(toolbar)
        }
        return function () { if (observer) observer.disconnect() }
      }, [rowsData.loading, append[0], props.nonce])
      function selectFile(next) {
        selected[1](next)
        var el = reader.current, main = el && el.closest('.i5-main')
        if (main && main.clientWidth - 40 < 740) requestAnimationFrame(function () {
          if (!el.isConnected) return
          el.scrollIntoView({ block: 'start', behavior: 'instant' })
          el.querySelector('h2').focus({ preventScroll: true })
        })
      }
      if (rowsData.error) return h(Iter5Error, { error: rowsData.error, retry: rowsData.retry })
      if (rowsData.loading) return h(Loading)
      return h('div', null,
        h('div', { className: 'i5-toolbar' },
          h('input', { type: 'search', placeholder: L('按标题或路径筛选', 'Filter titles or paths'), 'aria-label': L('筛选记忆文件', 'Filter memory files'), value: query[0], onChange: function (e) { query[1](e.target.value) } }),
          h('select', { 'aria-label': L('记忆范围', 'Memory scope'), value: scope[0], onChange: function (e) { scope[1](e.target.value) } }, [['all', L('全部范围', 'All scopes')], ['user', L('用户级', 'User')], ['project', L('本项目', 'This project')]].map(function (x) { return h('option', { key: x[0], value: x[0] }, x[1]) })),
          h('select', { 'aria-label': L('记忆分类', 'Memory category'), value: filter[0], onChange: function (e) { filter[1](e.target.value) } }, [['all', L('全部分类', 'All categories')], ['user', L('用户偏好', 'Preferences')], ['notes', L('项目笔记', 'Notes')], ['logs', L('日志', 'Logs')], ['reflections', L('反思', 'Reflections')]].map(function (x) { return h('option', { key: x[0], value: x[0] }, x[1]) })),
          h('button', { onClick: function () { if (append[0] && !window.confirm(L('关闭笔记编辑区？未保存的内容将丢失。', 'Close the note editor and discard unsaved text?'))) return; append[1](!append[0]) }, 'aria-expanded': append[0] }, L('追加笔记', 'Append note'))),
        append[0] ? h(Iter5Card, { title: L('追加项目笔记', 'Append project note') }, h(Iter5Note, { onSaved: rowsData.retry })) : null,
        h('div', { className: 'i5-list-detail' },
          h('div', { className: 'i5-card i5-file-list', 'aria-label': L('记忆文件', 'Memory files') }, rows.length ? rows.map(function (r) {
              return h('button', { key: r.path, className: 'i5-file', 'aria-current': r.path === path ? 'true' : undefined, onClick: function () { selectFile(r.path) } }, h('span', { className: 'i5-badge i5-badge-lg', 'data-hue': r.kind === 'user' ? 'pink' : r.kind === 'reflections' ? 'purple' : 'blue' }, h(Iter5Icon, { name: r.kind === 'user' ? 'heart' : 'note' })), h('span', { className: 'i5-file-copy' }, h('strong', null, r.label), h('small', null, r.kind === 'user' ? L('长期偏好与规则', 'Lasting preferences and rules') : r.kind === 'notes' ? L('项目笔记', 'Project notes') : r.kind === 'logs' ? L('每日日志', 'Daily log') : L('反思记录', 'Reflection')), h('span', { className: 'i5-tag' }, r.scope === 'user' ? L('用户级', 'User') : L('本项目', 'Workspace'))), h('small', null, fmtSize(r.size)))
          }) : h('p', { className: 'i5-empty' }, L('没有符合条件的记忆文件', 'No matching memory files'))),
          h('section', { ref: reader, className: 'i5-card i5-source-card', 'aria-label': L('记忆详情', 'Memory detail') },
            h('div', { className: 'i5-source-heading' }, h('span', { className: 'i5-badge', 'data-hue': 'blue' }, h(Iter5Icon, { name: 'note' })), h('h2', { tabIndex: -1 }, chosen ? chosen.label : L('记忆详情', 'Memory detail'))),
            chosen ? h('div', { className: 'i5-source-meta' }, h('span', { className: 'i5-tag' }, chosen.scope === 'user' ? L('用户偏好', 'User preferences') : L('项目记忆', 'Project memory')), h('span', null, fmtSize(chosen.size))) : null,
            file.error ? h(Iter5Error, { error: file.error, retry: file.retry }) : file.loading && path ? h(Loading) : chosen && file.data ? h(Iter5Document, { text: file.data.content || L('文件暂无内容。', 'This file is empty.') }) : h(Iter5Empty, { title: rows.length ? L('选择一段记忆', 'Select a memory') : L('没有符合条件的记忆文件', 'No matching memory files'), text: L('调整筛选条件，或追加新的项目笔记。', 'Adjust the filters or append a project note.') }),
            chosen ? h('div', { className: 'i5-source-origin' }, h('strong', null, L('文件来源', 'Source file')), h('small', null, file.data && file.data.path || path)) : null)))
    }
    function Iter5Memory(props) {
      var initial = { reflections: 'reflections', search: 'search', notes: 'browse' }[controller.panelTab()] || 'browse'
      var tab = useState(initial)
      var root = useRef(null)
      var items = [['browse', L('浏览', 'Browse')], ['logs', L('日志', 'Logs')], ['reflections', L('反思', 'Reflections')], ['search', L('检索', 'Search')]]
      var component = tab[0] === 'browse' ? Iter5Browse : tab[0] === 'search' ? Iter5Search : Iter5History
      return h('div', { ref: root }, h(Iter5Tabs, { id: 'i5-memory', label: L('记忆库分区', 'Memory sections'), items: items, value: tab[0], onChange: function(next) { if(root.current&&root.current.querySelector('[data-i5-dirty="true"]')&&!window.confirm(L('有未保存的笔记，确定切换？','Discard the unsaved note and switch?')))return;tab[1](next) } }),
        h('div', { role: 'tabpanel', id: 'i5-memory-panel', 'aria-labelledby': 'i5-memory-tab-' + tab[0] }, h(component, { key: tab[0], kind: tab[0], nonce: props.nonce, intent: props.intent })))
    }
    function Iter5Continue(props) {
      var tab = useState(controller.panelTab() === 'connect' ? 'external' : 'task')
      var items = [['task', L('当前任务', 'Current task')], ['board', L('白板', 'Whiteboard')], ['external', L('外部来源', 'External sources')]]
      return h('div', null, h(Iter5Tabs, { id: 'i5-continue', label: L('接续分区', 'Continuation sections'), items: items, value: tab[0], onChange: tab[1] }),
        h('div', { role: 'tabpanel', id: 'i5-continue-panel', 'aria-labelledby': 'i5-continue-tab-' + tab[0], className: 'i5-hosted' },
          tab[0] === 'external' ? h(Iter5External, { nonce: props.nonce }) : tab[0] === 'task' ? h(Iter5Handoff, { nonce: props.nonce }) : h('div', { className: 'i5-card' },
            tab[0] === 'board' ? h('p', { className: 'i5-muted' }, L('白板原文只读；编辑和接续执行由宿主负责。', 'Whiteboard source is read-only; the host manages editing and continuation.')) : null,
            h(PlanTab, { key: tab[0], nonce: props.nonce }))))
    }
    function Iter5Page(props) {
      var page = useState(function () { return iter5PageForTab(controller.panelTab()) })
      var refresh = useState(0), menu = useState(false), identityState = useState(iter5Identity), intent = useState(null), focus = useState(false)
      var lastTab = useRef(controller.panelTab())
      var root = useRef(null), menuButton = useRef(null)
      var content = useRef(null)
      var theme = useIter5Theme()
      var deep = theme[1], identity = iter5Identity()
      useEffect(function () {
        var el = root.current
        if (!el) return
        function measure() { el.setAttribute('data-narrow', String(el.clientWidth < 900)) }
        measure()
        var observer = typeof ResizeObserver === 'function' ? new ResizeObserver(measure) : null
        if (observer) observer.observe(el)
        return function () { if (observer) observer.disconnect() }
      }, [])
      // The host conversation surface scrolls above a floating composer. Use its
      // measured padding so our own scroller and save bar remain above that composer.
      useEffect(function () {
        var el = root.current, area = el && el.closest('[data-conversation-scroll]')
        if (!el || !area) return
        function fit() {
          var style = getComputedStyle(area)
          var height = area.clientHeight - (parseFloat(style.paddingBottom) || 0) - (parseFloat(style.paddingTop) || 0)
          var composer = document.querySelector('[data-composer-card]')
          if (composer) {
            var boundary = composer.getBoundingClientRect().top - area.getBoundingClientRect().top
            if (boundary > 0) height = Math.min(height, boundary)
          }
          el.style.height = Math.max(240, height) + 'px'
          el.style.maxHeight = Math.max(240, height) + 'px'
        }
        fit()
        var ro = typeof ResizeObserver === 'function' ? new ResizeObserver(fit) : null
        var mo = typeof MutationObserver === 'function' ? new MutationObserver(fit) : null
        if (ro) ro.observe(area)
        var composer = document.querySelector('[data-composer-card]')
        if (ro && composer) ro.observe(composer)
        if (mo) mo.observe(area, { attributes: true, attributeFilter: ['style', 'class'] })
        window.addEventListener('resize', fit)
        return function () { if (ro) ro.disconnect(); if (mo) mo.disconnect(); window.removeEventListener('resize', fit) }
      }, [])
      useEffect(function () { return controller.subscribe(function () {
        var next = controller.panelTab()
        if (next !== lastTab.current) { lastTab.current = next; page[1](iter5PageForTab(next)) }
      }) }, [])
      useEffect(function () { var timer = setInterval(function () { identityState[1](iter5Identity()) }, 500); return function () { clearInterval(timer) } }, [])
      useEffect(function () { if (content.current) content.current.scrollTop = 0 }, [page[0]])
      function nav(id, options) {
        if (root.current && root.current.querySelector('[data-i5-dirty="true"]') && !window.confirm(L('有未保存的修改，确定离开？', 'Discard unsaved changes and leave?'))) return
        if (page[0] === 'settings') delete iter5SettingsDrafts[iter5Identity() + '|workbench']
        intent[1](options || null); page[1](id); menu[1](false)
        var row = ITER5_PAGES.filter(function (p) { return p[0] === id })[0]
        if (row && id !== 'settings') controller.setPanelTab(row[4])
        if (id === 'team' || id === 'stats') controller.setPanelTab(id)
      }
      var meta = ITER5_PAGES.filter(function (p) { return p[0] === page[0] })[0]
      var title = meta ? L(meta[1], meta[2]) : page[0] === 'team' ? L('团队协作', 'Teamwork') : L('统计', 'Statistics')
      var nonce = String(props.nonce || 0) + ':' + refresh[0]
      var components = { home: Iter5Home, library: Iter5Memory, handoff: Iter5Continue, calendar: Iter5Calendar, skills: Iter5Skills, recall: Iter5Recall, mindmap: Iter5Workspaces, storage: Iter5Storage, settings: Iter5Settings, team: TeamTab, stats: StatsTab }
      var Component = components[page[0]] || Iter5Home
      function closeMenu() { menu[1](false); if (menuButton.current) menuButton.current.focus() }
      useEffect(function () {
        if (!menu[0] || !root.current) return
        var close = root.current.querySelector('[data-i5-close-nav]'); if (close) close.focus()
      }, [menu[0]])
      return h('div', { ref: root, 'data-iter5': '', 'data-deep': deep ? 'true' : 'false', 'data-focus': String(focus[0]), role: focus[0] ? 'dialog' : undefined, 'aria-modal': focus[0] ? true : undefined, 'aria-label': focus[0] ? L('记忆工作台', 'Memory workbench') : undefined, onKeyDown: function (e) {
        if (!focus[0]) return
        if (e.key === 'Escape' && !menu[0] && !root.current.querySelector('.i5-dialog')) { e.stopPropagation(); focus[1](false) }
        if (e.key === 'Tab') {
          var nodes = Array.from(root.current.querySelectorAll('button:not(:disabled),input:not(:disabled),select:not(:disabled),textarea,[tabindex="0"]')).filter(function (n) { return n.offsetParent !== null && n.tabIndex >= 0 })
          if (!nodes.length) return
          if (e.shiftKey && document.activeElement === nodes[0]) { e.preventDefault(); nodes[nodes.length - 1].focus() }
          else if (!e.shiftKey && document.activeElement === nodes[nodes.length - 1]) { e.preventDefault(); nodes[0].focus() }
        }
      }, style: { '--dam-user-scale': FONT_SCALE_VALUES[fontScale] || '1', '--i5-blue': accentTheme !== 'deepseek' && ACCENT_VALUES[accentTheme] ? 'color-mix(in srgb, ' + ACCENT_VALUES[accentTheme] + ' 70%, var(--i5-text))' : undefined, '--i5-fill': accentTheme !== 'deepseek' ? ACCENT_VALUES[accentTheme] : undefined } },
        h('button', { className: 'i5-mobile-menu', ref: menuButton, 'aria-expanded': menu[0], 'aria-label': L('打开导航', 'Open navigation'), onClick: function () { menu[1](!menu[0]) } }, '☰ ', L('记忆中枢', 'Memory')),
        menu[0] ? h('div', { className: 'i5-nav-backdrop', onClick: closeMenu }) : null,
        h('aside', { className: 'i5-sidebar', 'data-open': menu[0] ? 'true' : 'false', onKeyDown: function (e) {
          if (!menu[0]) return
          if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); closeMenu() }
          if (e.key === 'Tab') {
            var nodes = e.currentTarget.querySelectorAll('button'), first = nodes[0], last = nodes[nodes.length - 1]
            if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus() }
            else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus() }
          }
        } },
          h('button', { className: 'i5-close-nav', 'data-i5-close-nav': '', onClick: closeMenu }, L('关闭导航', 'Close navigation')),
          h('div', { className: 'i5-brand' }, h('span', { className: 'i5-brand-mark', 'aria-hidden': true }, h(Iter5Icon, { name: 'spark' })), h('div', null, h('strong', null, 'dsh-auto-memory'), h('small', null, L('让重要的事持久被记住', 'Keep what matters')))),
          h('nav', { 'aria-label': L('记忆导航', 'Memory navigation') }, ITER5_PAGES.map(function (p, i) { return h(React.Fragment, { key: p[0] }, i === 0 || i === 4 ? h('small', { className: 'i5-nav-label' }, i === 0 ? L('工作', 'Work') : L('扩展', 'More')) : null,
            h('button', { 'data-i5-nav': p[0], 'aria-current': page[0] === p[0] ? 'page' : undefined, onClick: function () { nav(p[0]) } }, h('span', { className: 'i5-badge', 'data-hue': p[3] }, h(Iter5Icon, { name: p[0] })), L(p[1], p[2]))) })),
          h('div', { className: 'i5-sidebar-foot' }, h('div', { className: 'i5-sidebar-art' }, h(Iter5Art, {})), h('div', { className: 'i5-side-caption' }, h('strong', null, L('记忆，在这里延续', 'Memory carries forward')), h('small', null, L('积累 · 回顾 · 接续', 'Keep · recall · continue'))), h('div', { className: 'i5-side-tools' }, h('button', { onClick: function () { nav('team') }, 'aria-current': page[0] === 'team' ? 'page' : undefined }, L('团队', 'Team')), h('button', { onClick: function () { nav('stats') }, 'aria-current': page[0] === 'stats' ? 'page' : undefined }, L('统计', 'Stats'))),
            h('button', { 'data-dam-skin-v4-exit': '', onClick: function () {
              if (root.current && root.current.querySelector('[data-i5-dirty="true"]') && !window.confirm(L('有未保存的修改，确定切回经典？', 'Discard unsaved changes and return to classic?'))) return
              if (page[0] === 'settings') delete iter5SettingsDrafts[iter5Identity() + '|workbench']
              damSkinSet('classic'); props.onExit()
            } }, L('返回经典皮肤', 'Back to classic')))),
        h('main', { ref: content, className: 'i5-main', key: identity, 'aria-label': title },
          h('header', { className: 'i5-page-head' }, h('div', null, h('h1', null, title), h('p', null, locale === 'zh' ? ({ home: '查看最近记录、今日日程与当前会话，继续手头的工作。', library: '集中查看用户偏好、项目笔记、每日日志与反思记录。', handoff: '让当前的目标、进度与经验，在下一段会话中继续。', calendar: '把待办与重要时刻放在一起，让每一天更从容。', recall: '回顾每一次记忆唤起，查看判定依据并留下反馈。', skills: '让反复验证的经验，沉淀为可复用的工作方法。', mindmap: '从工作区与记忆之间，发现持续连接的脉络。', storage: '查看记忆语料、维护索引，以及迁移你的积累。', settings: '决定记忆如何记录、唤回与接续，让它更适合你。' }[page[0]] || '记忆与任务，按当前工作区呈现') : 'Memory and tasks for the current workspace')),
            h('div', { className: 'i5-page-actions' }, h('button', { 'data-i5-theme': theme[0], 'aria-label': L('外观主题：', 'Appearance theme: ') + iter5ThemeLabel(theme[0]) + L('（点击切换 跟随 → 亮 → 暗）', ' (click to cycle auto → light → dark)'), title: L('主题：', 'Theme: ') + iter5ThemeLabel(theme[0]) + L('（点击切换）', ' (click to cycle)'), onClick: function () { theme[2](iter5ThemeCycle(theme[0])) } }, h(Iter5Icon, { name: iter5ThemeIcon(theme[0]) }), ' ', iter5ThemeLabel(theme[0])), h('button', { 'aria-label': focus[0] ? L('退出专注查看', 'Exit focused view') : L('专注查看', 'Focused view'), 'aria-pressed': focus[0], onClick: function () { focus[1](!focus[0]) } }, focus[0] ? L('返回会话', 'Back to conversation') : L('专注查看', 'Focused view')), h('button', { 'aria-label': L('刷新当前页', 'Refresh current page'), onClick: function () { if (root.current.querySelector('[data-i5-dirty="true"]') && !window.confirm(L('刷新会放弃未保存修改，继续？', 'Discard changes and refresh?'))) return; if (page[0] === 'settings') delete iter5SettingsDrafts[iter5Identity() + '|workbench']; refresh[1](refresh[0] + 1) } }, L('刷新', 'Refresh')))),
          h('div', { className: ['team', 'stats'].indexOf(page[0]) >= 0 ? 'i5-card i5-hosted' : '' }, h(Component, { key: page[0] + ':' + nonce + ':' + JSON.stringify(intent[0]), nonce: nonce, onNav: nav, intent: intent[0] })),
          page[0] === 'storage' ? h('details', { className: 'i5-card' }, h('summary', null, L('调试中心', 'Diagnostics')), h(DebugCenter), h('button', { onClick: function () { nav('settings', { group: 'behavior' }) } }, L('检查更新与高级设置', 'Updates and advanced settings'))) : null))
    }
